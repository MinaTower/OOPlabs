#include "Vector2D.h"

Vector2D::Vector2D(int init1, int init2) { x = init1; y = init2; };
void Vector2D::get(pair<int, int>& here) {
	here.first = x;
	here.second = y;
};
