#pragma once
#include<tuple>
using namespace std;

#ifndef L2_3_a_M_Vector2D_H
#define L2_3_a_M_Vector2D_H

class Vector2D
{
public:
	Vector2D(int init1, int init2);
	void get(pair<int, int>& here);
	Vector2D& operator+(const Vector2D& v2) {
		x = x + v2.x;
		y = y + v2.y;
		return *this;
	};
	Vector2D& operator=(const Vector2D& v2) {
		x = v2.x;
		y = v2.y;
		return *this;
	};
	Vector2D& operator-(const Vector2D& v2) {
		x = x - v2.x;
		y = y - v2.y;
		return *this;
	};
	Vector2D& operator*(const int multip) {//
		x = multip*x;
		y = multip*y;
		return *this;
	};
	bool& operator==(const Vector2D& v2) {
		double lenth_difference = (x * x + y * y) - ((v2.x) * v2.x + (v2.y) * v2.y);
		bool result;
		if (lenth_difference == 0) { result = true; }
		else { result = false; };
		return result;
	};
	bool& operator>(const Vector2D& v2) {
		double lenth_difference = (x * x + y * y) - ((v2.x) * v2.x + (v2.y) * v2.y);
		bool result;
		if (lenth_difference > 0) { result = true; }
		else { result = false; };
		return result;
	};
	bool& operator>=(const Vector2D& v2) {
		double lenth_difference = (x*x + y*y) - ((v2.x)*v2.x + (v2.y)*v2.y);
		bool result;
		if (lenth_difference >= 0) { result = true; }
		else { result = false; };
		return result;
	};
	bool& operator<(const Vector2D& v2) {
		double lenth_difference = (x * x + y * y) - ((v2.x) * v2.x + (v2.y) * v2.y);
		bool result;
		if (lenth_difference < 0) { result = true; }
		else { result = false; };
		return result;
	};
	bool& operator<=(const Vector2D& v2) {
		double lenth_difference = (x * x + y * y) - ((v2.x) * v2.x + (v2.y) * v2.y);
		bool result;
		if (lenth_difference <= 0) { result = true; }
		else { result = false; };
		return result;
	};
	~Vector2D() = default;
private:
	int x;
	int y;
};

#endif //L2_3_a_M_Vector2D_H