#pragma once
#include<vector>
#include "Shape.h"
using namespace std;

#ifndef L2_2_b_M_Rectangle_H
#define L2_2_b_M_Rectangle_H
class M_Rectangle :
    public Shape
{
public:
	M_Rectangle(int init1, int init2, int init3, int init4);
	virtual void paint(vector<int>& painting_inf);
	virtual ~M_Rectangle();
	virtual bool distinguish();
private:
	int x_1;
	int y_1;
	int x_2;
	int y_2;
};

#endif //L2_2_b_M_Rectangle_H
