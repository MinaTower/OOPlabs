#include "Shape.h"
Shape::Shape() {};
Shape::Shape(int init1, int init2, int init3, int init4) {
	x_1 = init1;
	y_1 = init2;
	x_2 = init3;
	y_2 = init4;
};
Shape::~Shape() {};
