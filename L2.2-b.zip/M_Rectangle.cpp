#include "M_Rectangle.h"
#include<vector>
using namespace std;

M_Rectangle::M_Rectangle(int init1, int init2, int init3, int init4) {
	x_1 = init1;
	y_1 = init2;
	x_2 = init3;
	y_2 = init4;
};
void M_Rectangle::paint(vector<int>& painting_inf) {
	painting_inf.push_back(x_1);
	painting_inf.push_back(y_1);
	painting_inf.push_back(x_2);
	painting_inf.push_back(y_2);
};

bool M_Rectangle::distinguish() { return false; };
M_Rectangle::~M_Rectangle() {};
