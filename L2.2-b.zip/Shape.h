#pragma once
#ifndef L2_2_b_Shape_H
#define L2_2_b_Shape_H
#include<vector>
using namespace std;
class Shape
{
public:
	Shape();
	Shape(int init1,int init2, int init3, int init4);
	virtual void paint(vector<int>& painting_inf) = 0;
	virtual bool distinguish() = 0;
	virtual ~Shape();
private:
	int x_1;
	int y_1;
	int x_2;
	int y_2;
};
#endif //L2_2_b_Shape_H
