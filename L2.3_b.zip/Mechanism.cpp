#include "Mechanism.h"

Mechanism::Mechanism() { inf1 = 0; };
Mechanism::Mechanism(Mechanism& obj) { inf1 = obj.inf1; };