#include "Detail.h"

Detail::Detail() { inf2 = 0; };
Detail::Detail(Detail& obj) { inf2 = obj.inf2; };