#pragma once
using namespace std;

#ifndef L2_3_b_Mechanism_H
#define L2_3_b_Mechanism_H

class Mechanism
{
public:
	virtual ~Mechanism() = default;
	friend Mechanism* set_Mechanism();
protected:
	Mechanism();
	Mechanism(Mechanism& obj);
private:
	int inf1;
};
#endif //L2_3_b_Mechanism_H
