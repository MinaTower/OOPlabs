#pragma once
#include "Mechanism.h"
using namespace std;

#ifndef L2_3_b_Detail_H
#define L2_3_b_Detail_H

class Detail :
    public Mechanism
{
public:
	friend Detail* set_Detail();
	virtual ~Detail() = default;
protected:
	Detail();
	Detail(Detail& obj);
private:
	int inf2;
};

#endif //L2_3_b_Detail_H
