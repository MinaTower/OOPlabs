﻿#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

#include <iostream>
#include<vector>
#include "Mechanism.h"
#include "Detail.h"

struct Leaks {
    ~Leaks() { _CrtDumpMemoryLeaks(); }
}_l;

namespace {
    const int NUM_OF_PAIRS_ = 2;
};
 
Mechanism* set_Mechanism() { return new Mechanism(); };
Detail* set_Detail() { return new Detail(); };

int main()
{
    vector<Mechanism*> storage;
    for (int iter = 0; iter < NUM_OF_PAIRS_;++iter) {
        storage.push_back((set_Mechanism()));
        storage.push_back((set_Detail()));
    };
    
    for (int iter = 0; iter < storage.size(); ++iter) {
        delete storage[iter];
    };
    storage.clear();
    return 0;
}
